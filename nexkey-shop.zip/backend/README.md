Backend setup:
1. Copy .env.example to .env and fill values.
2. npm install
3. npm run seed
4. npm run dev
