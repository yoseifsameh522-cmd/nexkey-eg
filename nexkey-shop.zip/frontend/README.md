Frontend setup: copy .env.example to .env, npm install, npm start
