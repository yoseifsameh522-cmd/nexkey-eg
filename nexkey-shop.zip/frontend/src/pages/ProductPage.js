import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useDispatchCart } from '../context/CartContext';
import { useParams, Link } from 'react-router-dom';

export default function ProductPage() {
  const { slug } = useParams();
  const [product, setProduct] = useState(null);
  const dispatch = useDispatchCart();

  useEffect(() => {
    axios.get(process.env.REACT_APP_API_URL + '/api/products/' + slug)
      .then(r => setProduct(r.data))
      .catch(e => console.log(e));
  }, [slug]);

  if (!product) return <div>جارٍ التحميل...</div>;

  return (
    <div style={{display:'flex', gap:20}}>
      <div style={{flex:1}}>
        <img src={process.env.REACT_APP_API_URL + product.image} alt='' style={{width:'100%', borderRadius:8}} />
      </div>
      <div style={{flex:1}}>
        <h2>{product.name}</h2>
        <p className='price'>{product.price} ج.م</p>
        <p>{product.description}</p>
        <div style={{marginTop:12}}>
          <button className='btn' onClick={() => dispatch({ type: 'ADD', payload: { id: product._id, name: product.name, price: product.price, quantity: 1 } })}>
            أضف إلى السلة
          </button>
          <Link to='/cart' style={{marginLeft:10}} className='btn'>اذهب للسلة</Link>
        </div>
      </div>
    </div>
  );
}
