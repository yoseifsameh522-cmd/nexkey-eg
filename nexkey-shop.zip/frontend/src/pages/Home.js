import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default function Home() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    axios.get(process.env.REACT_APP_API_URL + '/api/products')
      .then(res => setProducts(res.data))
      .catch(err => console.log(err));
  }, []);
  return (
    <div>
      <h2 className='center'>أفضل المنتجات</h2>
      <div className='products'>
        {products.map(p => (
          <div key={p._id} className='card'>
            <img src={process.env.REACT_APP_API_URL + p.image} alt={p.name} />
            <h3>{p.name}</h3>
            <p className='price'>{p.price} ج.م</p>
            <p>{p.description}</p>
            <div style={{display:'flex', gap:10, justifyContent:'flex-start', marginTop:8}}>
              <Link to={'/product/' + p.slug} className='btn'>عرض</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
