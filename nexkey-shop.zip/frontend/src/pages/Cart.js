import React, { useState } from 'react';
import { useCart, useDispatchCart } from '../context/CartContext';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Cart() {
  const cart = useCart();
  const dispatch = useDispatchCart();
  const navigate = useNavigate();
  const [customer, setCustomer] = useState({ name:'', phone:'', address:'' });
  const [loading, setLoading] = useState(false);

  const total = cart.items.reduce((s, i) => s + i.price * i.quantity, 0);

  const handleCOD = async () => {
    try {
      setLoading(true);
      const res = await axios.post(process.env.REACT_APP_API_URL + '/api/orders', {
        items: cart.items,
        total,
        paymentMethod: 'cod',
        customer
      });
      dispatch({ type: 'CLEAR' });
      setLoading(false);
      alert('تم إنشاء الطلب كدفع عند الاستلام. سنتصل بك للتأكيد.');
      navigate('/');
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert('فشل إنشاء الطلب');
    }
  };

  const handleStripe = async () => {
    try {
      setLoading(true);
      const res = await axios.post(process.env.REACT_APP_API_URL + '/api/stripe/create-checkout-session', {
        items: cart.items,
        successUrl: window.location.origin + '/success',
        cancelUrl: window.location.origin + '/cart',
        customer
      });
      window.location.href = res.data.url;
    } catch (err) {
      console.error(err);
      setLoading(false);
      alert('خطأ في تهيئة الدفع');
    }
  };

  return (
    <div>
      <h2 className='center'>السلة</h2>
      {cart.items.length === 0 ? <p className='center'>السلة فارغة</p> : (
        <div className='cart-list'>
          <ul>
            {cart.items.map(i => <li key={i.id}>{i.name} x {i.quantity} - {i.price} ج.م</li>)}
          </ul>
          <p><strong>الإجمالي: {total.toFixed(2)} ج.م</strong></p>

          <h3>تفاصيل العميل</h3>
          <input placeholder='اسمك' value={customer.name} onChange={e=>setCustomer({...customer, name:e.target.value})} />
          <input placeholder='رقم الهاتف' value={customer.phone} onChange={e=>setCustomer({...customer, phone:e.target.value})} />
          <textarea placeholder='العنوان' value={customer.address} onChange={e=>setCustomer({...customer, address:e.target.value})} />

          <div style={{display:'flex', gap:10, marginTop:10}}>
            <button className='btn' onClick={handleCOD} disabled={loading}>الدفع عند الاستلام</button>
            <button className='btn' onClick={handleStripe} disabled={loading}>الدفع ببطاقة (Stripe)</button>
          </div>
        </div>
      )}
    </div>
  );
}
