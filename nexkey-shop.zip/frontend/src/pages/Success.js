import React from 'react';
export default function Success() {
  return (
    <div className='center'>
      <h2>تم الدفع بنجاح ✅</h2>
      <p>شكرًا لك! سيتم تجهيز الطلب والتواصل معك قريبًا.</p>
    </div>
  );
}
