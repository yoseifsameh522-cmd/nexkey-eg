import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import ProductPage from './pages/ProductPage';
import Cart from './pages/Cart';
import Success from './pages/Success';
import { CartProvider } from './context/CartContext';

function App() {
  return (
    <CartProvider>
      <Router>
        <div className='container'>
          <nav className='navbar'>
            <Link to='/' className='brand'>NexKey</Link>
            <Link to='/cart' className='cart-btn'>السلة</Link>
          </nav>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/product/:slug' element={<ProductPage />} />
            <Route path='/cart' element={<Cart />} />
            <Route path='/success' element={<Success />} />
          </Routes>
        </div>
      </Router>
    </CartProvider>
  );
}

export default App;
